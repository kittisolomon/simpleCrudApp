<?php
require "db.php";
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="css/custom.css">
<title>ContactForm|Home</title>

</head>
<body>

<h1 class="h1">  Please Fill The Form Below... </h1>
<form method="POST" >
<div class="container">
	<div class="col col-6">
	<div class="form-input">
<label _for=""> Fullname: </label> 
<input type="text" name="fullname" class="input" data-input="cm" placeholder="Full Name">
</div>
</div>
<div class="col col-6">
	<div class="form-input">
<label _for=""> Phone Number: </label> 
<input type="text" name="phoneno" class="input" data-input="cm" placeholder="Enter phone Number">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<label _for=""> Email: </label> 
<input type="text" name="email" class="input" data-input="cm" placeholder="Enter Email">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<label _for=""> Address: </label> 
<input type="text" name="address" class="input" data-input="cm" placeholder="Enter Address">
</div>
</div>

<div class="col col-6">
	<div class="form-input">
<label _for=""> Message: </label> 
<textarea name="message" class="input" id=""placeholder="Write Your Message Here...." cols="6" rows="6">
</textarea>
</div>
<div class="form-input">
<input type="submit" name="submit" value="Send Message" class="button">
 </div>
</div>
</div></form>
</div>

</body>
</html>