<?php
// database class contains your App's Bussiness Logic.
 	class Database {
	
 	public	$con = null;
 		public function __construct(){
 			$this->con= mysqli_connect("localhost","root","","bootcamp");
 		if(!$this->con){
 			die("cannot connect to database".mysqli_error());
 		}
 	}

//This Method Inserts record into the database
 	function insert_contact($tablename,$fullname,$phoneno,$email,$address,$message){

 		$sql = null;
 		$sql.="INSERT INTO ". $tablename;
 		$sql .= "(fullname,phoneno,email,address,message) VALUES";
 		$sql .="('$fullname','$phoneno','$email','$address','$message')";
 		$query = mysqli_query($this->con,$sql);
 		if($sql){
 			header("location: contactform.php?msg= record sent");
 		}else {
 			die("cannot send record".mysqli_error());
 		}
 	}

//This method reads your inserted record, from database
 	function fetch_contact($tablename){
 		$sql = "SELECT * FROM ".$tablename;
 		$array = array();
 		$query = mysqli_query($this->con,$sql);
 		if($query){
 			while($row = mysqli_fetch_assoc($query)){
 				$array[] = $row;
 			}
 			return $array;
 		}else {
 			die;
 		}
 	}


 	function select_contact($tablename,$where){
 	$sql = null;
 	$condition = null;
 	foreach ($where as $key => $value) {
 		$condition.= $key ."='" . $value. "' AND ";
 	}
 	$condition = rtrim($condition," AND ");
 	$sql .= " SELECT * FROM ".$tablename." WHERE ".$condition;
 	$query = mysqli_query($this->con,$sql);
 
 	$row = mysqli_fetch_array($query);
 	return $row;
 	}

// This method updates a particular record, by overriding with current defined value(s)
 	function update_contact($tablename,$where,$Array){
 		$sql = null;
 		$condition = null;
 		foreach ($where as $key => $value) {
 			$condition.= $key."='".$value."' AND ";
 		}
 		$condition = rtrim($condition," AND ");
 	
 	foreach ($Array as $key => $value) {
 		$sql.= $key."='".$value."', ";
 	}
 	$sql = rtrim($sql,", ");
 	$sql ="UPDATE ".$tablename." SET ".$sql." WHERE ".$condition;
 	$query = mysqli_query($this->con,$sql);
 	if($query)
 	{
 		return true;
 	}else {
 		die("cannot update contact".mysqli_error());
 	}
 }

// As the method name implies, its simple deletes a record
 	function delete_contact($tablename,$where) {
 		$sql= null;
 		$condition = null;
 		foreach ($where as $key => $value) {
 			$condition.= $key. "='". $value."' AND ";
 		}
 		$condition = rtrim($condition," AND ");
 		$sql .= " DELETE FROM ".$tablename. " WHERE ".$condition;
 		$query = mysqli_query($this->con,$sql);
 		if($query){
 			return $query;
 		}else {
 			die("cannot delete contact".mysqli_error());
 		}
 	}

}

// initializing the object of the class
$obj = new Database;

	if(isset($_POST["submit"])){
		$fullname = $_POST["fullname"];
		$phoneno = $_POST["phoneno"];
		$email = $_POST["email"];
		$address = $_POST["address"];
		$message = $_POST["message"];
	$obj->insert_contact("contacts","$fullname","$phoneno","$email","$address","$message");
	 }


	 if(isset($_POST["edit"])){
	 	$id = $_GET["id"];
		$where = array("id"=>$id);
		$Array = array(
		"fullname" => $_POST["fullname"],
		"phoneno" => $_POST["phoneno"],
		"email" => $_POST["email"],
		"address" => $_POST["address"],
		"message" => $_POST["message"]
	);
	if($obj->update_contact("contacts",$where,$Array)){
	header("location:mycontact.php?msg=Contact Updated Successfully");
}
}

	if(isset($_GET["delete"])){
		$id = $_GET["id"];
		$where = array("id"=>$id);
		if($obj->delete_contact("contacts",$where)){
			header("location:mycontact.php?msg=Contact Deleted Successfully");
		}
	}	 

   //echo substr("Hello", 0, -2);

?>